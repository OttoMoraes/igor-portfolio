# Igor — Portfólio Profissional

Portfólio moderno e premium de **Igor**, Editor de Vídeo, Motion Designer e Criador de Conteúdo Visual.

🔗 **Site online:** _(adicione a URL do GitHub Pages aqui depois de publicar)_

---

## Como publicar no GitHub Pages

### 1. Crie um repositório no GitHub
1. Acesse [github.com/new](https://github.com/new)
2. Nome do repositório (escolha um):
   - `igor-portfolio`  
   - ou `seu-usuario.github.io` (para URL mais curta)
3. Deixe **público**
4. **Não** marque "Add a README"
5. Clique em **Create repository**

### 2. Envie os arquivos
No seu computador, abra o terminal na pasta do projeto e rode:

```bash
git init
git add .
git commit -m "Primeiro commit - portfólio Igor"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/NOME-DO-REPOSITORIO.git
git push -u origin main
```

> Substitua `SEU-USUARIO` e `NOME-DO-REPOSITORIO` pelos seus dados.

### 3. Ative o GitHub Pages
1. No repositório, vá em **Settings** → **Pages**
2. Em **Source**, escolha:
   - Branch: `main`
   - Folder: `/ (root)`
3. Clique em **Save**
4. Aguarde 1–2 minutos
5. A URL do site aparece na mesma página (ex: `https://seu-usuario.github.io/igor-portfolio/`)

---

## Estrutura do projeto

```
igor-portfolio/
├── index.html          # Página principal
├── css/styles.css      # Design System
├── js/main.js          # Interações
├── assets/
│   ├── icons/
│   └── images/
└── README.md
```

## Personalização

- Substitua os placeholders de **foto** pelas fotos reais do Igor
- Atualize os links de **WhatsApp, Instagram, e-mail e telefone**
- Adicione projetos reais no portfólio
- Troque os depoimentos de exemplo pelos reais

---

## Identidade Visual

| Elemento       | Valor                          |
|----------------|--------------------------------|
| Branco         | `#FFFFFF`                      |
| Preto          | `#111111`                      |
| Cinza claro    | `#F5F5F5`                      |
| Cinza médio    | `#CFCFCF`                      |
| **Destaque**   | `#F4C430` (amarelo moderno)    |

Feito com foco em profissionalismo, minimalismo e conversão.
